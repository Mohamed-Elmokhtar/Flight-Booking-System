<?php
include('dbm.php');
include('login.php');
?>