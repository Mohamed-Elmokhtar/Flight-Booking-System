<head>
	<div class="topnav">
		<a href="admin-dashboard.php">Dashboard</a>
		<a href="add-airplane.php">Manage Airplane</a>
		<a href="manage-flight.php">Manage Flights</a>
		<a href="add-flight.php">Add Flight</a>
		<div class="topnav-right">
			<a href="../login.php">Logout</a>
		</div>
	</div>
</head>