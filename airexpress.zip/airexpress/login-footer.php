<footer>
   <div id="footerSection">
      <div>
        <label style="display:inline; font-weight: bold; color:white">Contact Us:</label>
        <a href="#"><img class="contactus"src="images/instagram.png"></a><a href="#"><img class="contactus" src="images/facebookIcon.png" ></a>
        <a href="#"><img  class="contactus" src="images/twitter.png"></a>
         <a href="#"><img  class="contactus" src="images/emailContact.png"></a>
         </div>
      </div>
</footer>
